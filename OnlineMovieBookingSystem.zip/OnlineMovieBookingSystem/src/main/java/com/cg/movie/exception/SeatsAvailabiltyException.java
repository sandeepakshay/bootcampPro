package com.cg.movie.exception;

public class SeatsAvailabiltyException extends Exception {
	private static final long serialVersionUID = 1L;
	public SeatsAvailabiltyException(String msg)
	{
		super(msg);
	}

}
