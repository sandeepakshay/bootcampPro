package com.cg.movie.exception;

public class MovieIdNotFoundException extends Exception{
	private static final long serialVersionUID = 1L;

	public MovieIdNotFoundException(String msg) {
		super(msg);
	}
	

}
