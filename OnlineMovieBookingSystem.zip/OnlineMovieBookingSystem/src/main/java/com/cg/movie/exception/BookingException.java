package com.cg.movie.exception;

public class BookingException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public BookingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
