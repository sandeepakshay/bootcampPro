package com.cg.movie.exception;

public class BookingDateException extends Exception {
	private static final long serialVersionUID = 1L;	

	public BookingDateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
